<?xml version="1.0" encoding="UTF-8"?>
<tileset name="overworld(1)" tilewidth="16" tileheight="16" tilecount="189" columns="21">
 <image source="overworld(1).png" width="336" height="144"/>
</tileset>
