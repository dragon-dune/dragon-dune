<?xml version="1.0" encoding="UTF-8"?>
<tileset name="overworld small thin" tilewidth="8" tileheight="16" tilecount="378" columns="42">
 <image source="overworld.png" width="336" height="144"/>
</tileset>
