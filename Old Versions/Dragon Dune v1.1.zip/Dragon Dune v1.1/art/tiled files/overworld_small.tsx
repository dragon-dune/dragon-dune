<?xml version="1.0" encoding="UTF-8"?>
<tileset name="overworld small" tilewidth="8" tileheight="8" tilecount="756" columns="42">
 <image source="overworld.png" width="336" height="144"/>
</tileset>
