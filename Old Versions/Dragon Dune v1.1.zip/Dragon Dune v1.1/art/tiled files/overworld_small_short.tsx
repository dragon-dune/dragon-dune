<?xml version="1.0" encoding="UTF-8"?>
<tileset name="overworld small short" tilewidth="16" tileheight="8" tilecount="378" columns="21">
 <image source="overworld.png" width="336" height="144"/>
</tileset>
